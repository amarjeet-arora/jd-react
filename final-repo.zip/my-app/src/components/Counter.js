import { Component } from "react";

export default class Counter extends Component {
  componentDidMount() {
    console.log("loaded once ready");
  }
  componentDidUpdate() {
    console.log("calls everytime when state changes");
  }
  state = {
    count: 0,
  };
  inc = () => {
    this.setState((prevState) => {
      return {
        count: prevState.count + 1,
      };
    });
  };
  dec = () => {
    alert("dec called");
  };
  render() {
    return (
      <div>
        <p>the count is : {this.state.count}</p>
        <button onClick={this.inc}>INCREMENT</button>
        <button onClick={this.dec}>INCREMENT</button>
      </div>
    );
  }
}
