import { Component } from "react";
import Header from "./Header";
import Footer from "./Footer";
import Users from "./Users";
import AddUser from "./AddUser";
import Counter from "./Counter";

export default class MainApp extends Component {

componentDidUpdate(){
  const json= JSON.stringify(this.state.userdata)
  localStorage.setItem('jddata',json)
}
componentDidMount(){

  const json= localStorage.getItem('jddata')
  const userdata= JSON.parse(json)
  if(userdata){
    this.setState(() => ({userdata}))
  }
}


  state = {
    headerData: "welcome to header component",
    userdata: [],
  };

  addUser=(data)=>{
  this.setState((prevState)=>{
    return{
      userdata:prevState.userdata.concat(data)
    }
  })
  }
  deleteAll=()=>{
    this.setState(()=>{
      return{
        userdata:[]
      }
    })
  }
deleteOne=(dataToRemove)=>{
this.setState((prevState)=>{
  return{
  userdata:prevState.userdata.filter((option) => dataToRemove !== option)
  }
})
}
  render() {
    return (
      <div>
        <Header hdata={this.state.headerData} />
        <p>Welcome to MainApp</p>
        <Users udata={this.state.userdata} 
        da={this.deleteAll}
        hasdata={this.state.userdata.length >0}
        delOne={this.deleteOne}
        />
        <AddUser au={this.addUser}/>
        <Footer />
        <Counter />
      </div>
    );
  }
}
