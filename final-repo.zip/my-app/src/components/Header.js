function Header(props) {
  return (
    <div>
      <p>{props.hdata}</p>
    </div>
  );
}

export default Header;
