import { Component } from "react";
import User from "./User";

export default class Users extends Component {
  render() {
    return (
      <div>
         {
          this.props.udata.map((dat) =>  <User key={dat} ud={dat} delone={this.props.delOne}/>)
         }
       <button className="btn btn-danger" disabled={!this.props.hasdata} onClick={this.props.da}>Delete All</button>
      </div>
    );
  }
}
