function AddUser(props) {
  const addUser = (e) => {
    e.preventDefault();
    const data = e.target.elements.uname.value;
    props.au(data);
  };

  return (
    <div>
      <form onSubmit={addUser}>
        UserName: <input type="text" name="uname" className="form-control" />
        <button className="btn btn-primary">Add User</button>
      </form>
    </div>
  );
}
export default AddUser;
