import { Component } from "react";
import axios from "axios";
const URL = "https://jsonplaceholder.typicode.com/users";
export class RestApp extends Component {
  state = {
    users: [],
  };

  componentDidMount() {
    axios
      .get(URL)
      .then((response) => response.data)
      .then((data) => {
        this.setState({ users: data });
      });
  }

  render() {
    return (
      <div>
        User Data
        {this.state.users.map((user) => (
          <div key={user.id}>
            <h2>{user.username}</h2>
            <p>{user.email}</p>
          </div>
        ))}
      </div>
    );
  }
}
