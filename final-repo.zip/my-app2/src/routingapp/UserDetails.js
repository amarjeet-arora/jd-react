import React from 'react';

function UserDetails(props) {
    return (
        <div>
            UserDetails : {props.match.params.id}
        </div>
    );
}

export default UserDetails;