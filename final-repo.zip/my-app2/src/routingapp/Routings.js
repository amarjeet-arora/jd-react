import { BrowserRouter, Route, Switch } from "react-router-dom";
import Header from "./RoutingLink";
import Login from "./Login";
import Register from "./Register";
import PageNotFound from "./PageNotFound";
import UserDetails from "./UserDetails";
import Portfolio from "./Portfolio";
import LandingPage from "./LandingPage";




function Routings()  {
    return(
    <BrowserRouter>
      <div>
          <Header/>
      <Switch>
        <Route path="/" component={LandingPage} exact={true}/>
        <Route path="/login" component={Login} />
        <Route path="/register" component={Register} />
        <Route path="/userdetails/:id" component={UserDetails} />
        <Route path="/register" component={Portfolio} />
        <Route  component={PageNotFound}/>
        </Switch>
      </div>
    </BrowserRouter>
    )
}
export default Routings