import React from 'react';

function PageNotFound(props) {
    return (
        <div>
            oops... page not found
        </div>
    );
}

export default PageNotFound;