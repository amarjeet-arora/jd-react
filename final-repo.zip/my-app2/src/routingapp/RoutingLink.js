import { NavLink } from "react-router-dom"


function Header(){
    return(
        <header>
            <NavLink to="/" exact={true}>Home</NavLink> &nbsp;
            <NavLink to="/login">Login</NavLink> &nbsp;
            <NavLink to="/register">Register</NavLink> &nbsp;
            <NavLink to="/userdetails">Userdetails</NavLink> &nbsp;
            <NavLink to="/portfolio">Portfolio</NavLink> &nbsp;
        </header>
    )
}
export default Header