import React from "react";
 
function LandingPage(props) {
  return (
    <div>
      <p>landing page..</p>
      
    </div>
  );
}





export default LandingPage;
