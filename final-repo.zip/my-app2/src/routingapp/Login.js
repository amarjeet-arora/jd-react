import React from 'react';

function Login(props) {
    return (
        <div>
            <p>Login component</p>
        </div>
    );
}

export default Login;