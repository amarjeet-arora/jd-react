import { createContext, useContext, useState } from 'react'
const appContext= createContext()
function ContextApp() {
    const [employee]= useState({id:101,uname:'admin',loaction:'pune',salary:334456})
  return (
    <div>
      <p>Main Component</p>
      <appContext.Provider value={employee}>
      <Employee/>
      </appContext.Provider>
    
    </div>
  );
}

function Employee() {
    let empContext=useContext(appContext)
  return (
    <div>
      <p>Employee Component</p>
      <h2>{empContext.uname}</h2>
      <Salary />
    </div>
  );
}

function Salary() {
  return (
    <div>
      <p>Salary Component</p>
    </div>
  );
}
export default ContextApp;
