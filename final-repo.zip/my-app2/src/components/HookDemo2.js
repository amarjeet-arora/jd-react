import { useEffect, useState } from "react";

function Hookdemo2() {
  const [users, setUsers] = useState([]);
  const [title, setTitle] = useState("");
  const [email, setEmail] = useState("");

useEffect(()=>{
localStorage.setItem('users',JSON.stringify(users))
},[users])




  const addUser = (e) => {
    e.preventDefault();
    setUsers([...users, { title, email }]);
    setTitle("");
  };
  const deleteUser = (title) => {
    setUsers(users.filter((note) => note.title !== title));
  };
  return (
    <div>
      {users.map((user) => (
        <div key={user.title}>
          {user.title} --- {user.email}
          <button onClick={() => deleteUser(user.title)}>delete</button>
        </div>
      ))}
      <h2>Add User Info</h2>
      <form onSubmit={addUser}>
        UserName:
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        Email:{" "}
        <input
          type="text"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <button>AddUser</button>
      </form>
    </div>
  );
}
export default Hookdemo2;
