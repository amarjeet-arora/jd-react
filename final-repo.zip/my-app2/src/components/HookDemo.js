import { useEffect, useState } from "react";

function Hookdemo() {
  const [count, setCount] = useState(10);
// combo of didmount and didupdate
  useEffect(()=>{
    console.log('called only once');
  },[])
  useEffect(()=>{
    console.log('called on update');
  },[count])
  return (
    <div>
      <p>The current count is : {count}</p>
      <button onClick={() => setCount(count + 1)}>INC</button>
      <button onClick={() => setCount(count - 1)}>DEC</button>
    </div>
  );
}
export default Hookdemo;
