import "./App.css";
import Hookdemo2 from "./components/HookDemo2";

import Routings from "./routingapp/Routings";

function App() {
  return (
    <div className="App">
      <Hookdemo2/>
    </div>
  );
}

export default App;
