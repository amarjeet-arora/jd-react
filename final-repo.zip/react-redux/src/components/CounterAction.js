import React from 'react';
import { useDispatch } from 'react-redux'
import { increment } from '../redux/actions/counteraction';
function CounterAction(props) {
    const dispatch=useDispatch()
    return (
        <div>
            <button onClick={()=>dispatch(increment())}>inc</button>
        </div>
    );
}

export default CounterAction;