 import {useSelector} from 'react-redux'
 function CounterApp(props) {
    const counterState= useSelector((state => state.counter))
    return (
        <div>
            <p>The Current count is : {counterState}</p>
        </div>
    );
}

export default CounterApp;