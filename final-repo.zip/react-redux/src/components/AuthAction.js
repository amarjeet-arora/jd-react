import React from 'react';
import{useDispatch} from 'react-redux'
import { login, logout } from '../redux/actions/authActions';
function AuthAction(props) {
    const actionDispatch= useDispatch()
    return (
        <div>
            <button onClick={()=> actionDispatch(login())}>Login</button> &nbsp;
            <button onClick={()=> actionDispatch(logout())}>Logout</button>

        </div>
    );
}

export default AuthAction;