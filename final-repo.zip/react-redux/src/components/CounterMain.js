

import React from 'react';
import CounterApp from './CounterApp';
import CounterAction from './CounterAction';

function CounterMain(props) {
    return (
        <div>
            <CounterApp/>
            <CounterAction/>
        </div>
    );
}

export default CounterMain;