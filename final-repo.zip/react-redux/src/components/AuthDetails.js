import React from 'react';
import { useSelector } from 'react-redux'
function AuthDetails(props) {
    const authDetails= useSelector((state=> state.auth))
    return (
        <div>
            <p>For LoggedIn user Only..... (login to check the offers for you)</p>
            {
                authDetails ? (
                    <div>
                        <p>Congratulations you got an offer</p>
                        <h2>OPUY77897YU</h2>
                        <p>Use the below code to get 50% off...!</p>
                        </div>
                ) : (
                    "you are not in offer selections"
                )
            }
        </div>
    );
}

export default AuthDetails;