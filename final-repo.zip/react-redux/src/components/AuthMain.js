import React from 'react';
import AuthAction from './AuthAction';
import AuthDetails from './AuthDetails';

function AuthMain(props) {
    return (
        <div>
            <AuthAction/>
            <AuthDetails/>
        </div>
    );
}

export default AuthMain;