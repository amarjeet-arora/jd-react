import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";

export const getPhotos = createAsyncThunk("photos/getPhotos", async () => {
  const response = await fetch("https://picsum.photos/v2/list?page=36&limit=9");
  const formattedResponse = await response.json();
  return formattedResponse;
});

export const appSlice = createSlice({
  name: "gallery",
  initialState: {
    photos: [],
  },
  extraReducers: {
    [getPhotos.pending]: (state) => {},
    [getPhotos.fulfilled]: (state, action) => {
      state.photos = action.payload;
    },
  },
});
export default appSlice.reducer;
