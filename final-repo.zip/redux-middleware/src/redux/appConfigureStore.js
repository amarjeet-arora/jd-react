
import galleryReducer from './appState'
import {configureStore} from '@reduxjs/toolkit'

export const store= configureStore({
    reducer :{
        gallery:galleryReducer
    }
})