import React from "react";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getPhotos } from "../redux/appState";
function LoadPhotos(props) {
  const dispatch = useDispatch();
  const appstate = useSelector((state) => state.gallery.photos);
  useEffect(() => {2048
    dispatch(getPhotos());
    console.log(appstate);
  }, []);
  return <div></div>;
}

export default LoadPhotos;
