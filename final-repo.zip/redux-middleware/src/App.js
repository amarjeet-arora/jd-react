import logo from './logo.svg';
import './App.css';
import LoadPhotos from './components/LoadPhotos';

function App() {
  return (
    <div className="App">
    <LoadPhotos/>
    </div>
  );
}

export default App;
