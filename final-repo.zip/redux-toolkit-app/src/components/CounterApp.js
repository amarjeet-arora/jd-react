import React from 'react';
import { useSelector } from 'react-redux'
function CounterApp(props) {
    const appState=useSelector((state)=> state.counterRed.counter);
    return (
        <div>
            Welcome to Counter App : {appState}
        </div>
    );
}

export default CounterApp;