import React from 'react';
import { useDispatch } from 'react-redux'
import { incerement } from '../redux/AppSlice';
function CounterAction(props) {
    const action= useDispatch()
    return (
        <div>
            <button onClick={()=>action(incerement())}>inc</button>
        </div>
    );
}

export default CounterAction;