import React from 'react';
import CounterAction from './CounterAction';
import CounterApp from './CounterApp';

function CounterMain(props) {
    return (
        <div>
            <CounterAction/>
            <CounterApp/>
        </div>
    );
}

export default CounterMain;