import logo from './logo.svg';
import './App.css';
import CounterMain from './components/CounterMain';

function App() {
  return (
    <div className="App">
      <CounterMain/>
    </div>
  );
}

export default App;
