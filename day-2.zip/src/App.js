import logo from './logo.svg';
import './App.css';
import MainApp from './components/MainApp';
import { RestApp } from './RestApp';

function App() {
  return (
    <div className="App">
     <p>welcome to reactJS</p>
     <RestApp/>
    </div>
  );
}

export default App;
