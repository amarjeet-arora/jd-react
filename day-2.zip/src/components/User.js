import { Component } from "react";

export default class User extends Component {
  render() {
    return (
      <div>
      {this.props.ud}
      <button onClick={()=>this.props.delone(this.props.ud)}>delete</button>
      </div>
    );
  }
}
